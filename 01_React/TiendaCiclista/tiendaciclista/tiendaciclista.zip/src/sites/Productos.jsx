import ListaProductos from '../components/ListaProductos'

var Productos = () => {
    return (
        <>
            <ListaProductos />
        </>
    )
}

export default Productos